const express = require('express');
const app = express();

// middleware
app.use(express.json());

// test endpoint
app.get('/', (req, res) => {
  res.send('Backend is alive');
});

// real endpoint
app.post('/detect', (req, res) => {
  const profile = req.body;
  // dummy logic for now
  const result = {
    score: 42,
    result: 'Likely Fake'
  };
  res.json(result);
});

const PORT = 3000;

// Make sure it's binding to 0.0.0.0
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://0.0.0.0:${PORT}`);
});